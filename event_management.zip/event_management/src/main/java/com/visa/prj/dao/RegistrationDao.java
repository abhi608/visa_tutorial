package com.visa.prj.dao;

import com.visa.prj.entity.Registration;

public interface RegistrationDao {
	void register(Registration reg);
}
